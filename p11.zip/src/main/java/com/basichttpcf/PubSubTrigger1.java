package com.basichttpcf;

import com.basichttpcf.PubSubTrigger1.PubSubMessage;
import com.google.api.core.ApiFuture;
import com.google.api.gax.rpc.NotFoundException;
import com.google.cloud.bigquery.*;
import com.google.cloud.functions.BackgroundFunction;
import com.google.cloud.functions.Context;
import com.google.cloud.pubsub.v1.Publisher;
import com.google.cloud.pubsub.v1.SchemaServiceClient;
import com.google.cloud.pubsub.v1.TopicAdminClient;
import com.google.gson.Gson;
import com.google.protobuf.ByteString;
import com.google.pubsub.v1.*;
import com.google.pubsub.v1.Schema;
import org.apache.avro.io.Encoder;
import org.apache.avro.io.EncoderFactory;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.Base64;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;
import java.util.logging.Logger;


public class PubSubTrigger1 implements BackgroundFunction<PubSubMessage> {
    public static final String project_id = "datapipeline20220728";
    private static final Logger logger = Logger.getLogger(PubSubTrigger1.class.getName());

    public static void createJob(String query, String run_id) {
        try {
            // Initialize client that will be used to send requests. This client only needs to be created
            // once, and can be reused for multiple requests.
            BigQuery bigquery = BigQueryOptions.getDefaultInstance().getService();

            // Specify a job configuration to set optional job resource properties.
            QueryJobConfiguration queryConfig = QueryJobConfiguration.newBuilder(query).build();

            // The location and job name are optional,
            // if both are not specified then client will auto-create.
            String jobName = run_id + "_jobId_" + UUID.randomUUID();
            JobId jobId = JobId.newBuilder().setLocation("us").setJob(jobName).build();

            // Create a job with job ID
            Job job = bigquery.create(JobInfo.of(jobId, queryConfig));

            if (job.getJobId().getJob().equals(jobId.getJob())) {
                logger.info("Job created successfully." + job.getJobId().getJob());
                logger.info("Job status" + job.getStatus().toString());
            } else {
                logger.info("Job was not created");
            }

            //insert this run id information in status table
            write_to_runstatus_table(bigquery, query, run_id, job.getJobId().toString());
            write_to_status_pubsub(project_id,"statusTopic","statusSchema");
        } catch (Exception e) {
            logger.info("MyError , Job was not created. error details" + e);
        }

    }//createjob

    public static void write_to_runstatus_table(BigQuery bQuery, String query, String run_id, String bqjobid) throws InterruptedException {
        String insertQuery = " insert into `datapipeline20220728.sample_db.cf_run_status` values (?,?,CURRENT_DATE() )";

        QueryJobConfiguration insertConfig = QueryJobConfiguration.newBuilder(insertQuery)
                .addPositionalParameter(QueryParameterValue.string(run_id))
                .addPositionalParameter(QueryParameterValue.string(bqjobid))
                .build();

        logger.info("built query is " + insertConfig.getQuery());
        // Execute the query.
        TableResult results = bQuery.query(insertConfig);
        results.iterateAll()
                .forEach(row -> row.forEach(val -> logger.info(val.toString())));

    }

    public static com.google.pubsub.v1.Schema getSchema(String projectId, String schemaId) throws IOException {
        SchemaName schemaName = SchemaName.of(projectId, schemaId);
        com.google.pubsub.v1.Schema schema=null;
        try (SchemaServiceClient schemaServiceClient = SchemaServiceClient.create()) {

         schema = schemaServiceClient.getSchema(schemaName);

            logger.info("Got a schema:\n" + schema);



        } catch (NotFoundException e) {
            logger.info(schemaName + "not found.");
        }
        return schema;
    }

    @Override
    public void accept(PubSubMessage message, Context context) {

        logger.info("Received context with eventId " + context.eventId());
        logger.info("Received context with timestamp " + context.timestamp());
        logger.info("Received context with toString " + context);
        logger.info("Received context with attributes  " + context.attributes().entrySet());
        logger.info("Received context with resource " + context.resource());


        if (null != message.data) {
            String ipJsonString = new String(Base64.getDecoder().decode(message.data));
            logger.info("mylog" + ipJsonString);

            //   Map jsonJavaRootObject = new Gson().fromJson("{/*whatever your mega complex object*/}", Map.class)
            Map jsonJavaRootObject = new Gson().fromJson(ipJsonString, Map.class);
            String query = (String) jsonJavaRootObject.get("sql");
            String locale = (String) jsonJavaRootObject.get("locale");
            String run_id = (String) jsonJavaRootObject.get("run_id");
            logger.info("approach 2 : query=" + query + " ,locale=" + locale);

            createJob(query, run_id);

        }//some data is present

    }//accept

    public static void write_to_status_pubsub(String projectId, String topicId, String schemaId) throws IOException, ExecutionException, InterruptedException {
        //write to pub_sub status topic
        Schema schema = getSchema(project_id, schemaId);
        String schemaStr = schema.getDefinition();
        logger.info("schemaStr=" + schemaStr);

        org.apache.avro.Schema createdAvroSchema = new org.apache.avro.Schema.Parser().parse(schemaStr);
        logger.info("createdAvroSchema getDoc=" + createdAvroSchema.getDoc());
        logger.info("createdAvroSchema toString=" + createdAvroSchema);
        TopicName topicName = TopicName.of(project_id, topicId);

        Encoding encoding = null;
        // Get the topic encoding type.
        try (TopicAdminClient topicAdminClient = TopicAdminClient.create()) {
            encoding = topicAdminClient.getTopic(topicName).getSchemaSettings().getEncoding();
        }
        logger.info("Encoding is :" + encoding);


        Publisher publisher = null;
        try {
            publisher = Publisher.newBuilder(topicName).build();
            ByteArrayOutputStream byteStream = new ByteArrayOutputStream();
            Encoder encoder = EncoderFactory.get().jsonEncoder(createdAvroSchema, byteStream);
            encoder.flush();

            ByteString data = ByteString.copyFrom(byteStream.toByteArray());
            PubsubMessage message = PubsubMessage.newBuilder().setData(data).build();
            logger.info("Publishing message: " + message);

            ApiFuture<String> future = publisher.publish(message);
            logger.info("Published message ID: " + future.get());

        } finally {
            if (publisher != null) {
                publisher.shutdown();
                publisher.awaitTermination(1, TimeUnit.MINUTES);
            }//if
        }//finally

    }//write_to_status_pubsub

    public static class PubSubMessage {
        String data;
        Map<String, String> attributes;
        String messageId;
        String publishTime;
    }


}//outer class
